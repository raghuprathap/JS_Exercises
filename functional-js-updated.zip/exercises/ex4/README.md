# Instructions

1. Define `pickNumbers(..)` so that it's a pure function (other than the randomness!) which generates a new random lottery number (using `lotteryNum()`) and adds it to the list.

2. `pickNumbers(..)` should always keep the list of lottery numbers sorted in ascending order. Also, no duplicates!
