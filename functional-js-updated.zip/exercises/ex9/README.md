# Instructions

1. Run the exercise solution file (HTML) in the browser and observe how the countdown timer operates in the console. The countdown timer prints the starting countdown value ("0:05") immediately, then counts down once per second to "0:00", then prints "Complete!".

2. Now, run the original exercise file (HTML) in the browser and compare the difference in (broken) behavior.

3. Attach `formatCountdown(..)` to the `countdown` observable, and fill in the implementation (`// TODO` comment) so that the countdown timer prints as specified above.
