function foo() { /* .. */ }

var x = foo(3,4);

x();	// 7
x();	// 7
