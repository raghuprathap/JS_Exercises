# Instructions

1. Make a pure function `bar(..)` to wrap around `foo(..)`.

2. Make a pure function `bar(..)` that "adapts" `foo(..)` to avoid its side effects.
